<?php
$servername = "localhost";
$username = "id7176067_root";
$password = "123456";
$dbname = "id7176067_trading";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql= "DELETE FROM register WHERE email='$_POST[email]'";

if ($conn->query($sql) === TRUE) {
     header("location:admin1.php?err=1");
    
   
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>