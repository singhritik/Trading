<?php
        $host = "localhost";
        $dbUsername = "id7176067_root";
        $dbPassword = "123456";
        $dbname = "id7176067_trading";

       
       
      

// Create connection
$conn = mysqli_connect($host,$dbUsername,$dbPassword,$dbname);
// Check connection
if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
}
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$email=$_POST["email"];

$sql= "INSERT into register (fname, lname, email, adhaarno, panno, mobileno) values ('$_POST[fname]', '$_POST[lname]','$_POST[email]','$_POST[adhaarno]','$_POST[pcno]','$_POST[mobileno]')";

if (mysqli_query($conn, $sql)) {
    
    
	// Authorisation details.
	$username = "ritiksingh8269@outlook.com";
	$hash = "9e7ee51b00d11204d2a4453bcc6700f38d400d7cebf79d6a51cc8a25ee19ccbd";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers = "8269952793,9522735368"; // A single number or a comma-seperated list of numbers
	$message = "Dear Ankit Namdev new customer register on your website there name is $fname $lname and Email is $email please contact to customer and give its referal id and password for singin on your website.";
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	curl_close($ch);
    

    header("location:index.php");
} else {
echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?> 