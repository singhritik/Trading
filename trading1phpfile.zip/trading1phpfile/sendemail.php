<?php
	header('Content-type: application/json');
	$status = header("Location: http://glifix.tk/");
	$alert = "Thanks for the response, we'll get back you soon";
	

    $name = @trim(stripslashes($_POST['name'])); 
    $email = @trim(stripslashes($_POST['email'])); 
    $subject = @trim(stripslashes($_POST['subject'])); 
    $message = @trim(stripslashes($_POST['message'])); 

    $email_from = $email;
    $email_to = 'ritiksingh8269@gmail.com';//replace with your email

    $body = 'Name: ' . $name . "\n\n" . 'Email: ' . $email . "\n\n" . 'Subject: ' . $subject . "\n\n" . 'Message: ' . $message;

    $success = @mail($email_to, $subject, $body, 'From: <'.$email_from.'>');
    
    

  /*
  here i want to show the alert from javascript to the user that your response is recieved and we'll get back you soon
  */
  
  
    echo $status;
    die;
    
    ?>