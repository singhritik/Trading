<?php
$servername = "localhost";
$username = "id7176067_root";
$password = "123456";
$dbname = "id7176067_trading";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "UPDATE update1 SET date='$_POST[date]', live_price='$_POST[live_price]', quantity='$_POST[quantity]', inv_price='$_POST[inv_price]', days_gain='$_POST[days_gain]', days_gainp='$_POST[days_gainp]', overall_gain='$_POST[overall_gain]', overall_gainp='$_POST[overall_gainp]', latest_value='$_POST[latest_value]', total_price='$_POST[total_price]', profit_loss='$_POST[profit_loss]' WHERE referalid='$_POST[referalid]' AND companyname='$_POST[companyname]'";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
   
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>