<?php
    
    session_start();
    if(!isset($_SESSION["login"]))
        header("location:login1.php");
    

    $conn = mysqli_connect("localhost","id7176067_root","123456","id7176067_trading") or die("Server connection failed : ".mysqli_error());
    

    $sql = "SELECT * FROM admin WHERE adminid='".$_SESSION["login"]."'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
    // output data of each row
        while($row = $result->fetch_assoc()) {
            $name= $row["name"]; 
            $email=$row["email"];
            $address=$row["address"];
            $mobileno=$row["mobileno"];
        }
    } else {
        echo "0 results";
    }
    $conn->close();


?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <title>My Trading</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8" />
    <meta name="keywords" content="Pervasive Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- Custom Theme files -->
    <link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
    <link href="css/style.css" type="text/css" rel="stylesheet" media="all">
    <!-- font-awesome icons -->
    <link href="css/fontawesome-all.min.css" rel="stylesheet">
	<!-- //Custom Theme files -->
    <!-- online-fonts -->
    <link href="http://fonts.googleapis.com/css?family=Ubuntu:300,300i,400,400i,500,500i,700,700i" rel="stylesheet">
    <!-- //online-fonts -->
</head>

<body>
    <!-- banner -->
    <div class="inner-banner">
        <!-- header -->
        <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-gradient-secondary pt-3">
                <h1>
                    <a class="navbar-brand text-white" href="index1.php">
                       <img src="images/logo.png" width=50%>
                    </a>
                </h1>
                <button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-lg-auto text-center">
                        <li class="nav-item  mr-3 mt-lg-0 mt-3">
                            <?php echo " ".ucfirst($name)." " ?>
                        </li>
                       
                        <li class="nav-item active mr-3 mt-lg-0 mt-3">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
			</nav>
        </header>
        <!-- //header -->
         <div class="container">
            <!-- banner-text -->
            <div class="banner-text">
                <div class="slider-info">
                    <h3>Welcome<?php echo " ".ucfirst($name)." "?> </h3>
                </div>
            </div>
        </div>
    </div>
	







    <div class="container-fluid" aria-label="breadcrumb">
        <br>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="admin.php">Home</a></li>
                <li class="breadcrumb-item"><a href="admin.php">Customer Profile</a></li>
                <li class="breadcrumb-item"><a href="admin.php">Update</a></li>
                <li class="breadcrumb-item"><a href="admin1.php">Customer Data</a></li>
                <li class="breadcrumb-item"><a href="logout.php">Logout</a></li>
            </ol>
        </nav>
    	<div style="border: 1px solid #DAD6D5; border-radius: 10px;" class="p-3 mb-2 bg-light text-dark">
		   	<div style="color: blue;">
            <h5>Name            : <?php echo " ".ucfirst($name)." "?></h5>
            <h5>Email           : <?php echo " ".ucfirst($email)." "?></h5>
            <h5>Address         : <?php echo " ".ucfirst($address)." "?></h5>
            <h5>Mobile Number   : <?php echo " ".ucfirst($mobileno)." "?></h5>
        </div><br>
            
            
        <div id="home1" style="border: 1px solid #DAD6D5; border-radius: 10px;" class="p-1 mb-1 bg-light text-dark">
            <form action="delete1.php" method="post">
        	     <!-- contact -->
                <div class="contact-wthree py-1" id="register">
                	<div class="container py-lg-5">
                    	
                        <div class="project-top mx-auto mt-lg-0">
                            <!-- register form grid -->
                            <div class="register-top1">
                                 <div class="form-group">
                                    <div class="row">
										<div class="col-md-12">
                                         <?php
                   							 if(isset($_REQUEST["errr"])){
                        					        echo '<script language="javascript">';
                                                    echo 'alert("Record Delete Successfully")';
                                                    echo '</script>';
                   							 }
                						?>  
                                           
                                        </div>
                                    </div>
                                </div>   
                                <div class="form-group">
                                      
                                    <div class="row">
                                        <div class="col-md-4">
                                        	<h4 class="tittle-w3ls">Delete Customers Data</h4> 
                                        </div>
        								<div class="col-md-4">
                                                   
                                            <input class="form-control" type="text" placeholder="Enter Serial number" name="id" required="">
                                        </div>
                                        <div class="col-md-4">
                                            <button type="submit" class="btn btn-success btn-block w-50">Submit</button>
                                        </div>
                                    </div>
                                </div>                                
                            </div>                        <!--  //register form grid ends here -->
                        </div>               
                	</div>
            	</div>
            </form>
    	</div>                
    	<br>
    	
    	    
        <div id="home1" style="border: 1px solid #DAD6D5; border-radius: 10px;" class="p-1 mb-1 bg-light text-dark">
            <form action="Delete.php" method="post">
        	     <!-- contact -->
                <div class="contact-wthree py-1" id="register">
                	<div class="container py-lg-5">
                    	
                        <div class="project-top mx-auto mt-lg-0">
                            <!-- register form grid -->
                            <div class="register-top1">
                                <div class="form-group">
                                    <div class="row">
										<div class="col-md-12">
                                         <?php
                   							 if(isset($_REQUEST["err"])){
                        					        echo '<script language="javascript">';
                                                    echo 'alert("Registeration cancel Successfully")';
                                                    echo '</script>';
                   							 }
                						?>  
                                           
                                        </div>
                                    </div>
                                </div>    
                                <div class="form-group">
                                    <div class="row">
        								<div class="col-md-4">
                                           <h4 class="tittle-w3ls">Manage Registeration</h4>  
                                            
                                        </div>
        								<div class="col-md-4">
                                                   
                                            <input class="form-control" type="text" placeholder="Enter Email id" name="email" required="">
                                        </div>
                                        <div class="col-md-4">
                                            <button type="submit" class="btn btn-success btn-block w-50">Submit</button>
                                        </div>
                                    </div>
                                </div>                                
                            </div>                        <!--  //register form grid ends here -->
                        </div>               
                	</div>
            	</div>
            </form>
    	</div>                
    	<br>
    	
    	
    	
    	<div id="home1" style="border: 1px solid #DAD6D5; border-radius: 10px;" class="p-1 mb-1 bg-dark text-white">
		 <form action="" method="post">
	     <!-- contact -->
        	<div class="contact-wthree py-1" id="register">
        		<div class="container py-lg-5">
            		
                    <div class="project-top mx-auto mt-lg-0 mt-1">
                        <!-- register form grid -->
                        <div class="register-top1">
                            
                                <div class="form-group">
                                    <div class="row">
										<div class="col-md-4">
                                           
                                            <h4 class="tittle-w3ls">Search Customer Data</h4>
                                        </div>
                                        <div class="col-md-4 inpt-form">
                                           <input class="form-control" type="text" placeholder="Enter Referal Id" name="referalid" required="">
                                             
                                        </div>
                                        <div class="col-md-4 inpt-form">
                                           <button type="submit" class="btn btn-success btn-block w-50">Submit</button>
                                        </div>
                                    </div>
                                </div>                                
                        </div>                        <!--  //register form grid ends here -->
                    </div>               
            	</div>
        	</div>
        </form>
    	</div>
<br>
    	
    	
    	
    	
    	
            <div class="contact-wthree py-md-1 py-1" id="register">
        		<div class="container py-lg-1">
            		<div class="text-center wthree-title pb-sm-1 pb-2">
                		<h4 class="tittle-w3ls pb-1">Customer's All Data</h4>               
            		</div>
                    <div class="project-top mx-auto mt-lg-0 mt-1">
                        <!-- register form grid -->
                        <div class="table-responsive">
                			<table class="table">
			                    <thead class="thead-dark">
			                        <tr>
			                              <th scope="col">S No.</th>  
                        			      <th scope="col">Customer Name</th>
                        			      <th scope="col">Company</th>
                        			      <th scope="col">Referal Id</th>
                        			      <th scope="col">Date</th>
                        			      <th scope="col">Live Price</th>			    
                        			      <th scope="col">Quantity</th>
                        			      <th scope="col">Inv. Price</th>
                        			      <th scope="col">Day's Gain</th>
                        			      <th scope="col">Day's Gain%</th>
                        			      <th scope="col">Overall Gain</th>
                        			      <th scope="col">Overall Gain%</th>
                        			      <th scope="col">Latest Value</th>
                        			      <th scope="col">Total price</th>
                        			      <th scope="col">Profit/Loss</th>
                                    </tr>
			                    </thead>
			                    <tbody>
			  	
                			  	<?php
                				    $host = "localhost";
                				    $dbUsername = "id7176067_root";
                				    $dbPassword = "123456";
                				    $dbname = "id7176067_trading";
                                       // Create connection
                                    $conn = mysqli_connect($host,$dbUsername,$dbPassword,$dbname);
                                    // Check connection
                                    if (!$conn) {
                                    die("Connection failed: " . mysqli_connect_error());
                                    }
                				    
                				    $sql = "SELECT * FROM update1 where referalid='".$_POST["referalid"]."'";
                				    $result = $conn->query($sql);
                
                				    if ($result->num_rows > 0) {
                				    // output data of each row
                				        while($row = $result->fetch_assoc()) { ?>
                				            <tr>
                				             <td scope="row"><?php echo $row['id'] ?></td>    
                				             <td scope="row"><?php echo $row['cname'] ?></td>
                			      			  <td scope="row"><?php echo $row['companyname'] ?></td>
                						      <td scope="row"><?php echo $row['referalid'] ?></td>
                						      <td scope="row"><?php echo $row['date'] ?></td>
                						      <td scope="row"><?php echo $row['live_price'] ?></td>
                						      <td scope="row"><?php echo $row['quantity'] ?></td>
                						      <td scope="row"><?php echo $row['inv_price'] ?></td>
                						      <td scope="row"><?php echo $row['days_gain'] ?></td>
                						      <td scope="row"><?php echo $row['days_gainp'] ?></td>
                						      <td scope="row"><?php echo $row['overall_gain'] ?></td>
                						      <td scope="row"><?php echo $row['overall_gainp'] ?></td>
                						      <td scope="row"><?php echo $row['latest_value'] ?></td>
                						      <td scope="row"><?php echo $row['total_price'] ?></td>
                						      <td scope="row"><?php echo $row['profit_loss'] ?></td>
                						     </tr> 	
                						  <?php    
                				        }
                				    } else {
                				        echo "RESULT NOT FOUND";
                				    }
                
                				    $conn->close();
                				?>
                			    </tbody>
			                </table>
                		</div>                        <!--  //register form grid ends here -->
                    </div>               
            	</div>
        	</div>
    	</div>
    	<br><br>
	</div>





	<div class="copyright py-3">
		<p class="copy-right text-center ">&copy; 2018 Pervasive. All Rights Reserved | Design by Ritik singh</a>
		</p>
	</div>
	<!-- //footer -->


<!-- js -->
    <script src="js/jquery-2.2.3.min.js"></script>
<!-- //js -->
    <!-- start-smooth-scrolling -->
    <script src="js/move-top.js"></script>
    <script src="js/easing.js"></script>
    <script src="js/SmoothScroll.min.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html>