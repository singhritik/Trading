<?php
    
    session_start();
    if(!isset($_SESSION["login"]))
        header("location:login1.php");
    

    $conn = mysqli_connect("localhost","id7176067_root","123456","id7176067_trading") or die("Server connection failed : ".mysqli_error());
    

    $sql = "SELECT * FROM admin WHERE adminid='".$_SESSION["login"]."'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
    // output data of each row
        while($row = $result->fetch_assoc()) {
            $name= $row["name"]; 
            $email=$row["email"];
            $address=$row["address"];
            $mobileno=$row["mobileno"];
        }
    } else {
        echo "0 results";
    }
    $conn->close();


?>


<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <title>My Trading</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8" />
    <meta name="keywords" content="Pervasive Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- Custom Theme files -->
    <link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
    <link href="css/style.css" type="text/css" rel="stylesheet" media="all">
    <!-- font-awesome icons -->
    <link href="css/fontawesome-all.min.css" rel="stylesheet">
	<!-- //Custom Theme files -->
    <!-- online-fonts -->
    <link href="http://fonts.googleapis.com/css?family=Ubuntu:300,300i,400,400i,500,500i,700,700i" rel="stylesheet">
    <!-- //online-fonts -->
</head>

<body>
    <!-- banner -->
    <div class="inner-banner">
        <!-- header -->
        <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-gradient-secondary pt-3">
                <h1>
                    <a class="navbar-brand text-white" href="index1.php">
                       <img src="images/logo.png" width=50%>
                    </a>
                </h1>
                <button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-lg-auto text-center">
                        <li class="nav-item  mr-3 mt-lg-0 mt-3">
                            <?php echo " ".ucfirst($name)." " ?>
                        </li>
                       
                        <li class="nav-item active mr-3 mt-lg-0 mt-3">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
			</nav>
        </header>
        <!-- //header -->
         <div class="container">
            <!-- banner-text -->
            <div class="banner-text">
                <div class="slider-info">
                    <h3>Welcome<?php echo " ".ucfirst($name)." "?> </h3>
                </div>
            </div>
        </div>
    </div>
	







    <div class="container-fluid" aria-label="breadcrumb">
    	<br>
		<nav aria-label="breadcrumb">
	  		<ol class="breadcrumb">
	    		<li class="breadcrumb-item"><a href="#home1">Home</a></li>
	    		<li class="breadcrumb-item"><a href="#cprofile">Customer Profile</a></li>
	    		<li class="breadcrumb-item"><a href="#update">Update</a></li>
	    		<li class="breadcrumb-item"><a href="admin1.php">Customer Data</a></li>
	    		<li class="breadcrumb-item"><a href="logout.php">Logout</a></li>
	  		</ol>
		</nav>
		<div id="home1" style="border: 1px solid #DAD6D5; border-radius: 10px;" class="p-3 mb-2 bg-light text-dark">
		 <form action="referalid.php" method="post">
	     <!-- contact -->
        	<div class="contact-wthree py-md-5 py-4" id="register">
        		<div class="container py-lg-5">
            		<div class="text-center wthree-title pb-sm-5 pb-3">
                		<h4 class="tittle-w3ls pb-4">Update Referal Id & Password of Customers</h4>               
            		</div>
                    <div class="project-top mx-auto mt-lg-0 mt-2">
                        <!-- register form grid -->
                        <div class="register-top1">
                            
                                <div class="form-group">
                                    <div class="row">
										<div class="col-md-4">
                                           
                                            <input class="form-control" type="text" placeholder="Enter Referal Id" name="referalid" required="">
                                        </div>
                                        <div class="col-md-4 inpt-form">
                                           
                                            <input class="form-control" type="text" placeholder="Enter Password" name="password" required="">
                                        </div>
                                        <div class="col-md-4 inpt-form">
                                           
                                            <input class="form-control" type="text" placeholder="Enter User email" name="email" required="">
                                        </div>
                                    </div>
                                </div>                                
                                <div class="row mt-lg-5 mt-3">                                  
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-success btn-block w-100">Submit</button><br>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="reset" class="btn btn-primary btn-block w-100">Reset</button>
                                    </div>
                                </div>                            
                        </div>                        <!--  //register form grid ends here -->
                    </div>               
            	</div>
        	</div>
        </form>
    	</div>
    	<br><br>




    	<div id="cprofile" style="border: 1px solid #DAD6D5; border-radius: 10px;" class="p-3 mb-2 bg-warning text-dark">
		 <form action="updatet.php" method="post">
	     <!-- contact -->
        	<div class="contact-wthree py-md-5 py-4" id="register">
        		<div class="container py-lg-5">
            		<div class="text-center wthree-title pb-sm-5 pb-3">
                		<h4 class="tittle-w3ls pb-4">Create Customer Profile</h4>               
            		</div>
                    <div class="project-top mx-auto mt-lg-0 mt-2">
                        <!-- register form grid -->
                        <div class="register-top1">
                            
                                <div class="form-group">
                                    <div class="row">
										<div class="col-md-4">
                                           
                                            <input class="form-control" type="text" placeholder="Enter customer name" name="cname" required="">
                                        </div>
                                        <div class="col-md-4 inpt-form">
                                           
                                            <input class="form-control" type="text" placeholder="Company name" name="companyname" required="">
                                        </div>
                                        <div class="col-md-4 inpt-form">
                                           
                                            <input class="form-control" type="text" placeholder="Enter Referalid" name="referalid" required="">
                                        </div>
                                    </div>
                                </div>                                
                                <div class="row mt-lg-5 mt-3">                                  
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-success btn-block w-100">Submit</button><br>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="reset" class="btn btn-primary btn-block w-100">Reset</button>
                                    </div>
                                </div>                            
                        </div>                        <!--  //register form grid ends here -->
                    </div>               
            	</div>
        	</div>
        </form>
        </div>
    	<br><br>

    	<div id="cprofile" style="border: 1px solid #DAD6D5; border-radius: 10px;" class="p-3 mb-2 bg-dark text-white">
		 <form action="insertupdate.php" method="post">
	     <!-- contact -->
        	<div class="contact-wthree py-md-5 py-4" id="register">
        		<div class="container py-lg-5">
            		<div class="text-center wthree-title pb-sm-5 pb-3">
                		<h4 class="tittle-w3ls pb-4">Update Cutomer Data</h4>               
            		</div>
                    <div class="project-top mx-auto mt-lg-0 mt-2">
                        <!-- register form grid -->
                        <div class="register-top1">
                            
                                <div class="form-group">
                                    <div class="row">
										<div class="col-md-4">
                                           
                                            <input class="form-control" type="text" placeholder="Enter Referalid" name="referalid" required="">
                                        </div>
                                        <div class="col-md-4 inpt-form">
                                           
                                            <input class="form-control" type="text" placeholder="Company name" name="companyname" required="">
                                        </div>
                                        <div class="col-md-4 inpt-form">
                                           
                                            <input class="form-control" type="text" placeholder="yyyy-mm-dd" name="date" required="">
                                        </div>
                                    </div>
                                </div> 
                                <div class="form-group">
                                    <div class="row">
										<div class="col-md-6">
                                           
                                            <input class="form-control" type="text" placeholder="Enter Live Price" name="live_price" required="">
                                        </div>
                                       
                                        <div class="col-md-6 inpt-form">
                                           
                                            <input class="form-control" type="text" placeholder="Quantity" name="quantity" required="">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
										<div class="col-md-4">
                                           
                                            <input class="form-control" type="text" placeholder="Inv. Price" name="inv_price" required="">
                                        </div>
                                        <div class="col-md-4 inpt-form">
                                           
                                            <input class="form-control" type="text" placeholder="Day's Gain" name="days_gain" required="">
                                        </div>
                                        <div class="col-md-4 inpt-form">
                                           
                                            <input class="form-control" type="text" placeholder="Day's Gain %" name="days_gainp" required="">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
										<div class="col-md-4">
                                           
                                            <input class="form-control" type="text" placeholder="Over all Gain" name="overall_gain" required="">
                                        </div>
                                        <div class="col-md-4 inpt-form">
                                           
                                            <input class="form-control" type="text" placeholder="Over all Gain %" name="overall_gainp" required="">
                                        </div>
                                        <div class="col-md-4 inpt-form">
                                           
                                            <input class="form-control" type="text" placeholder="Latest Value" name="latest_value" required="">
                                        </div>
                                    </div>
                                </div> 
                                <div class="form-group">
                                    <div class="row">
										<div class="col-md-6">
                                           
                                            <input class="form-control" type="text" placeholder="Enter Total Price" name="total_price" required="">
                                        </div>
                                       
                                        <div class="col-md-6 inpt-form">
                                           
                                            <input class="form-control" type="text" placeholder="Profit/Loss" name="profit_loss" required="">
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-lg-5 mt-3">                                  
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-success btn-block w-100">Submit</button><br>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="reset" class="btn btn-primary btn-block w-100">Reset</button>
                                    </div>
                                </div>                            
                        </div>                        <!--  //register form grid ends here -->
                    </div>               
            	</div>
        	</div>
        </form>
    	</div>
    	<br><br>


	</div>





	<div class="copyright py-3">
		<p class="copy-right text-center ">&copy; 2018 Pervasive. All Rights Reserved | Design by Ritik singh</a>
		</p>
	</div>
	<!-- //footer -->


<!-- js -->
    <script src="js/jquery-2.2.3.min.js"></script>
<!-- //js -->
    <!-- start-smooth-scrolling -->
    <script src="js/move-top.js"></script>
    <script src="js/easing.js"></script>
    <script src="js/SmoothScroll.min.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html>