<?php
    
    session_start();
    if(!isset($_SESSION["login"]))
        header("location:login1.php");
    


    $host = "localhost";
    $dbUsername = "id7176067_root";
    $dbPassword = "123456";
    $dbname = "id7176067_trading";

    
   // Create connection
$conn = mysqli_connect($host,$dbUsername,$dbPassword,$dbname);
// Check connection
if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
}

    $sql = "SELECT * FROM register WHERE referalid='".$_SESSION["login"]."'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
    // output data of each row
        while($row = $result->fetch_assoc()) {
            $name= $row["fname"]; 
            $lname=$row["lname"];
            $email=$row["email"];
            $adhaar=$row["adhaarno"];
            $panno=$row["panno"];
            $mobileno=$row["mobileno"];
        }
    } else {
        echo "0 results";
    }
    $conn->close();


?>


<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <title>My Trading</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8" />
    <meta name="keywords" content="Pervasive Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- Custom Theme files -->
    <link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
    <link href="css/style.css" type="text/css" rel="stylesheet" media="all">
    <!-- font-awesome icons -->
    <link href="css/fontawesome-all.min.css" rel="stylesheet">
	<!-- //Custom Theme files -->
    <!-- online-fonts -->
    <link href="http://fonts.googleapis.com/css?family=Ubuntu:300,300i,400,400i,500,500i,700,700i" rel="stylesheet">
    <!-- //online-fonts -->
</head>

<body>
    <!-- banner -->
    <div class="inner-banner">
        <!-- header -->
        <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-gradient-secondary pt-3">
                 <h1>
                    <a class="navbar-brand text-white" href="index1.php">
                        <img src="images/logo.png" width=50%>
                    </a>
                </h1>
                <button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-lg-auto text-center">
                        <li class="nav-item  mr-3 mt-lg-0 mt-3">
                            <?php echo " ".ucfirst($name)." ".ucfirst($lname)." " ?>
                        </li>
                       
                        <li class="nav-item active mr-3 mt-lg-0 mt-3">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
			</nav>
        </header>
        <!-- //header -->
         <div class="container">
            <!-- banner-text -->
            <div class="banner-text">
                <div class="slider-info">
                    <h3>Welcome<?php echo " ".ucfirst($name)." ".ucfirst($lname)." "?> </h3>
                </div>
            </div>
        </div>
    </div>
    <br>
	

<div class="container-fluid">
	<div style="border: 1px solid #DAD6D5; border-radius: 10px;" class="p-3 mb-2 bg-light text-dark">
		<div style="color: blue;">
			<h5>Name 			: <?php echo " ".ucfirst($name)." ".ucfirst($lname)." "?></h5>
			<h5>Email 			: <?php echo " ".ucfirst($email)." "?></h5>
			<h5>PAN Number 		: <?php echo " ".ucfirst($panno)." "?></h5>
			<h5>Adhaar Number 	: <?php echo " ".ucfirst($adhaar)." "?></h5>
			<h5>Mobile Number 	: <?php echo " ".ucfirst($mobileno)." "?></h5>
		</div>
		<br>
		<center><button type="button" class="btn btn-primary" Onclick="myfunction()">Withdrawal</button></center>
		<script>
		function myfunction(){
			alert("Please contact to Admin");
		}
		</script>
		<br>
		<div class="table-responsive">
			<table class="table">
			  <thead class="thead-dark">
			    <tr>
			      <th scope="col">Customer Name</th>
			      <th scope="col">Company</th>
			      <th scope="col">Referal Id</th>
			      <th scope="col">Date</th>
			      <th scope="col">Live Price</th>			    
			      <th scope="col">Quantity</th>
			      <th scope="col">Inv. Price</th>
			      <th scope="col">Day's Gain</th>
			      <th scope="col">Day's Gain%</th>
			      <th scope="col">Overall Gain</th>
			      <th scope="col">Overall Gain%</th>
			      <th scope="col">Latest Value</th>
			      <th scope="col">Total Price</th>
			      <th scope="col">Profit/Loss</th>
			      
			    </tr>
			  </thead>
			  <tbody>
			  	
			  	<?php
				    $host = "localhost";
				    $dbUsername = "id7176067_root";
				    $dbPassword = "123456";
				    $dbname = "id7176067_trading";
                       // Create connection
                    $conn = mysqli_connect($host,$dbUsername,$dbPassword,$dbname);
                    // Check connection
                    if (!$conn) {
                    die("Connection failed: " . mysqli_connect_error());
                    }
				    
				    $sql = "SELECT * FROM update1 WHERE referalid='".$_SESSION["login"]."'";
				    $result = $conn->query($sql);

				    if ($result->num_rows > 0) {
				    // output data of each row
				        while($row = $result->fetch_assoc()) { ?>
				            <tr>
				             <td scope="row"><?php echo $row['cname'] ?></td>
			      			  <td scope="row"><?php echo $row['companyname'] ?></td>
						      <td scope="row"><?php echo $row['referalid'] ?></td>
						      <td scope="row"><?php echo $row['date'] ?></td>
						      <td scope="row"><?php echo $row['live_price'] ?></td>
						      <td scope="row"><?php echo $row['quantity'] ?></td>
						      <td scope="row"><?php echo $row['inv_price'] ?></td>
						      <td scope="row"><?php echo $row['days_gain'] ?></td>
						      <td scope="row"><?php echo $row['days_gainp'] ?></td>
						      <td scope="row"><?php echo $row['overall_gain'] ?></td>
						      <td scope="row"><?php echo $row['overall_gainp'] ?></td>
						      <td scope="row"><?php echo $row['latest_value'] ?></td>
						      <td scope="row"><?php echo $row['total_price'] ?></td>
						      <td scope="row"><?php echo $row['profit_loss'] ?></td>
						     </tr> 	
						  <?php    
				        }
				    } else {
				        echo "0 results";
				    }

				    $conn->close();
				?>

			    
			    
			    		    
			  </tbody>
			</table>
		</div>
	</div>     
</div>


	
	<div class="copyright py-3">
		<p class="copy-right text-center ">&copy; 2018 Pervasive. All Rights Reserved | Design by Ritik singh</a>
		</p>
	</div>
	<!-- //footer -->


<!-- js -->
    <script src="js/jquery-2.2.3.min.js"></script>
<!-- //js -->
    <!-- start-smooth-scrolling -->
    <script src="js/move-top.js"></script>
    <script src="js/easing.js"></script>
    <script src="js/SmoothScroll.min.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html>