<?php

	session_start();
	$Cser = mysqli_connect("localhost","id7176067_root","123456","id7176067_trading") or die("Server connection failed : ".mysqli_error());
	
    $uname = $_REQUEST["referid"];
    $upassword = $_REQUEST["password"];
    
    if ($uname=="abhi123") {
         $a = "select * from admin where adminid='".$uname."' and password='".$upassword."'";
         $result = mysqli_query($Cser,$a);
         $count = mysqli_num_rows($result);

          if ($count>0) {
            $_SESSION["login"]=$uname;
            header("location:admin.php");
        }
        else
        {
            header("location:login1.php?err=1");
        }

    }

    else
    {

        $s = "select * from register where referalid='".$uname."' and password='".$upassword."'"; 
        $result = mysqli_query($Cser,$s); 
        $count = mysqli_num_rows($result);
        if($count>0)
        {
            $_SESSION["login"]=$uname;
            header("location:userprofile.php");
        }
        else
        {    
            header("location:login1.php?err=1");
        }
    }    
?>