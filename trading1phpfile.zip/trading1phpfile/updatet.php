<?php
     $host = "localhost";
        $dbUsername = "id7176067_root";
        $dbPassword = "123456";
        $dbname = "id7176067_trading";
      

// Create connection
$conn = mysqli_connect($host,$dbUsername,$dbPassword,$dbname);
// Check connection
        if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
        }   
        $sql= "INSERT into update1 (cname,companyname,referalid) values ('$_POST[cname]','$_POST[companyname]','$_POST[referalid]')";

        if(mysqli_query($conn, $sql)){
            
             echo "Record updated successfully";
        }
        else{
           echo "Error: " . $sql . "<br>" . mysqli_error($conn);
           
        }
        mysql_close($conn);
       
?>