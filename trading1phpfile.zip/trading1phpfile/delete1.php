<?php
$servername = "localhost";
$username = "id7176067_root";
$password = "123456";
$dbname = "id7176067_trading";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "DELETE FROM update1 WHERE id='$_POST[id]'";

if ($conn->query($sql) === TRUE) {
    
    header("location:admin1.php?errr=1");
    
   
} else {
    header("location:admin1.php?err=1");
}

$conn->close();
?>