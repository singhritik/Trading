

<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <title>My Trading</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8" />
    <meta name="keywords" content="Pervasive Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- Custom Theme files -->
    <link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
    <link href="css/style.css" type="text/css" rel="stylesheet" media="all">
    <!-- font-awesome icons -->
    <link href="css/fontawesome-all.min.css" rel="stylesheet">
	<!-- pop up box -->
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
    <!-- //Custom Theme files -->
    <!-- online-fonts -->
    <link href="http://fonts.googleapis.com/css?family=Ubuntu:300,300i,400,400i,500,500i,700,700i" rel="stylesheet">
    <!-- //online-fonts -->
</head>


<body>
    <!-- banner -->
    <div class="inner-banner">
        <!-- header -->
        <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-gradient-secondary pt-3" style="position: fixed; background-color: gray;">
                <h1>
                    <a class="navbar-brand text-white" href="index1.php">
                        <img src="images/logo.png" width=50%>
                    </a>
                </h1>
                <button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-lg-auto text-center">
                        <li class="nav-item  mr-3 mt-lg-0 mt-3">
                            <a class="nav-link" href="index.php">Home
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item active  mr-3 mt-lg-0 mt-3">
                            <a class="nav-link" href="about.php">About</a>
                        </li>
						<li class="nav-item mr-3 mt-lg-0 mt-3">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>
			</nav>
        </header>
        <!-- //header -->
        
    </div>
	 <!-- //banner-text -->

	 <!-- counter -->
	<div class="services-bottom stats services py-lg-5">
		<div class="container py-5">
			<div class="row wthree-agile-counter">
				 
					<div class="col-lg-3 col-md-6 col-sm-6 w3_agile_stats_grid-top">
						<div class="w3_agile_stats_grid">
							<div class="agile_count_grid_left">
								<i class="far fa-clock"></i>
							</div>
							<div class="agile_count_grid_right">
								<p class="counter">1543</p> 
								<h4>Working Hours</h4>
							</div>
							<div class="clearfix"> </div>
							
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6 w3_agile_stats_grid-top">
						<div class="w3_agile_stats_grid">
							<div class="agile_count_grid_left">
								<i class="far fa-star"></i>
							</div>
							<div class="agile_count_grid_right">
								<p class="counter">434</p>
								<h4>Feedbacks</h4>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6 w3_agile_stats_grid-top">
						<div class="w3_agile_stats_grid">
							<div class="agile_count_grid_left">
								<i class="far fa-heart"></i>
							</div>
							<div class="agile_count_grid_right">
								<p class="counter">234</p>
								<h4>Happy Clients</h4>					
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
			</div>
		</div>
	</div>
<!-- //counter -->
<!---728x90--->





	<div style="padding-right: 10%; padding-left: 10%;">
	 	<br><br><br>
	 	<div style="border: 1px solid #DAD6D5; border-radius: 10px;">
	 	<div style="padding: 10px;">
	 		<h3 style="color: lightblue">About Us </h3>
	 		<hr>
	 		<p style="padding:10px">The the global research is a research house and an invstment esearch group carrying out operations in the indian Equities and commodity market. We generate intraday as well as delivery calls in stock cash and F&O in NSE & BSE, Commodities including billions, metal & Agro-commodities traded in MCX and NCDX. Our most important value is integrity. No matter who our direct client is, we are always aware that in the end, we are sheperding someone's hard-earned resources. We strive to deserve their trust in our character and competence.</p>
	 		<p style="padding:10px">As per our telephonic conversation our company is offer to manage your PMS with the investment of Rs. 50,000/- in company's pull/D-mate account with the help of our highly qualified researchers and our management team. Our company assure you that we are giving you 10% return on intraday of your actual investment. Company invest your captal safely in following segment like equity, commodity, currency etc. Your saving or currnt bank.</p>
	 		<p style="padding:10px">After the compilation of your investment and required document, you will received the Agreement, mail, and all the updatation of process time to time. As per the agreement 10% of your investment will be credited each and every working day in your specified account detail given by you in our company.</p>
	 	</div>
	 	</div>
	 	<br><br><br>
	 	<div style="border: 1px solid #DAD6D5; border-radius: 10px;">
	 	<div style="padding: 10px;">
	 		<h3 style="color: lightblue">Feature of PMS</h3>
	 		<hr>
	 		<p style="padding:10px">1. With the right manager, you can get superior retruns with least possible rist. </p>
	 		<p style="padding:10px">2. Performance fees only. No management fee.</p>
	 		<p style="padding:10px">3. Greater flexibility and larger opportunty set in the market.</p>
	 		<p style="padding:10px">4. For the conservative, long-term saver, enabling retirement, children's education or future family goals.</p>
	 		<p style="padding:10px">5. PMS is an alternative to mutual funds for the knowledgeable and educator investor.</p>
	 		<p style="padding:10px">6. We invest for you in marketable securities (stocks, bonds, etc.) with the goal of growing your assets at a rate which is materially above average without using high levels of debt or risk</p>
	 		<p style="padding:"10px">7. We strongly discourage short-term traders and stock market punters from applying for our service, as our short-term result may be volatile.</p><br><br>
	 		<p style="padding: 10px"> The GLOBAL has been making inroadss in the marketing world for 5 years. We are an innovative and  seasoned group of marketing professionals with experience handling the needs of a variety of clients. Our work in the stock industry has demonstrated significant achievement, and garnered lasting results, and we hope to provide you with outstanding services for your business.</p>
	 		<p style="padding: 10px"> We offer one of the best services in the equity and commodity trends for intraday, holding and investment services as well.</p>
	 	</div>
	 	</div>
	 	<br><br><br>
	 	<div style="border: 1px solid #DAD6D5; border-radius: 10px;">
	 	<div style="padding: 10px;">
	 		<h3 style="color: lightblue">Terms & Conditions:</h3>
	 		<hr>
	 		<ol>
	 			<li>Minimum investment Indian 50,000 rupees.</li>
	 			<li>Profit the amount 10-20% (intraday) of investment at the loss risk.</li>
	 		</ol>
	 		<ol>
	 			<br><h6>Capaite</h6>
	 			<li>Our accuracy stand above 80-90% in the intraday basis.</li>
	 			<li>Your services period stand for 30 working days.</li>
	 			<li>Maximum loss ratio is 10% of your investment at intraday basis</li>
	 		</ol>
	 		<ol>
	 			<br><h6>Loss T&C</h6>
	 			<li>Above loss ratio prier to guaranteed recovery by the company.</li>
	 		</ol>
	 	</div>
	 	</div>
	 	<br><br><br>
	 	<div style="border: 1px solid #DAD6D5; border-radius: 10px;">
	 	<div style="padding: 10px;">
	 		<h3 style="color: lightblue">Agreement:</h3>
	 		<hr>
	 		<h6 style="padding: 10px"> Agreement for listing on instructional trading platform of PMS (Portfolio management services)</h6>
	 		<p style="padding: 10px">This Agreement made of 03/02/2001 of <strong>The Global Research Online</strong> and <strong>SEBI (Security Exchange Board of India)</strong> Registration number is <strong>INA100010059</strong> Registered name is <strong>Jitendra Sikligar.</strong></p>
	 		<br><br>
	 		<h5 style="padding: 10px">About of PMS service</h5>
	 		<p style="padding: 10px">It's totally Portfolio Management Services within this services <strong>D-mat</strong> handling work by market expert and profit ratio is <strong>80-20</strong> or loss recovery plan by companies.</p>
	 		<p style="padding: 10px"> The global research have been got good <strong>opportunity</strong> from <strong>National Stock Exchange Market(NSE)</strong>.</p>
	 		<br><br>
	 	</div>
	 	</div>
	</div>
	<br><br><br>	



	<!-- footer -->
	<footer class="footer-emp bg-dark py-5">
		<div class="container">
			<div class="row footer-top">
				<div class="col-lg-4 footer-grid pr-5">
					<h2 class="footer-title border-bottom text-uppercase mb-4 pb-3">About Us</h2>
					<div class="footer-text">
		
						<p>I am Ankit Namdev. On behalf of the global research Services is writing this letter to offer our portfolio Management services.</p>


					</div>
				</div>
				<div class="col-lg-4 footer-grid my-lg-0 my-4">
					<h3 class="footer-title border-bottom text-uppercase mb-4 pb-3">Quick Links</h3>
					<ul class="links list-unstyled">
						<li>
							<a href="index.php">Home</a>
						</li>
						<li class="my-2">
							<a href="about.php">About Us</a>
						</li>
						<li class="mt-2">
							<a href="contact.php">Contact</a>
						</li>
					</ul>
					
					
				</div>
				<div class="col-lg-4 footer-grid">
					<h3 class="footer-title border-bottom text-uppercase mb-4 pb-3">Contact Us</h3>
					<div class="contact-info">
						<ul class="list-unstyled">
							<li>
								<div class="row">
									<div class="col-1">
										<i class="fas fa-map-marker"></i>
									</div>
									<div class="col-11">
										<p>The Global Research Online
											<span>Flat No 101,102 1st Floor, BCM heights, Opposite Mit City Hostel, Avantikapuri 1st lane, Ujjain</span></p>
									</div>
								</div>
							</li>
							<li class="my-2">
								<div class="row">
									<div class="col-1">
										<i class="fas fa-phone"></i>
									</div>
									<div class="col-11">
											<p>+91 9522735368</p>
									</div>
								</div>
							</li>
							<li>
								<div class="row">
									<div class="col-1">
										<i class="fas fa-envelope"></i>
									</div>
									<div class="col-11">
										<a href="mailto:info@theglobalresearchonline.com">info@theglobalresearchonline.com</a>
									</div>
								</div>
							</li>
						</ul>

					</div>
					<ul class="footer-social mt-md-4 mt-3">
						<li class="mx-2">
							<a href="#">
								<span class="fab fa-facebook-f"></span>
							</a>
						</li>
						<li class="mx-2">
							<a href="#">
								<span class="fab fa-twitter"></span>
							</a>
						</li>
						<li class="mx-2">
							<a href="#">
								<span class="fab fa-google-plus-g"></span>
							</a>
						</li>
						<li class="mx-2">
							<a href="#">
								<span class="fab fa-linkedin-in"></span>
							</a>
						</li>
						<li class="mx-2">
							<a href="#">
								<span class="fas fa-rss"></span>
							</a>
						</li>
						<li class="mx-2">
							<a href="#">
								<span class="fab fa-vk"></span>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
	<div class="copyright py-3">
		<p class="copy-right text-center ">&copy; 2018 Pervasive. All Rights Reserved | Design by Ritik singh </a>
		</p>
	</div>


	<!-- //footer -->

<!-- js -->
    <script src="js/jquery-2.2.3.min.js"></script>
<!-- //js -->
<!-- stats -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.countup.js"></script>
		<script>
			$('.counter').countUp();
		</script>
   <script src="js/move-top.js"></script>
    <script src="js/easing.js"></script>
    <script src="js/SmoothScroll.min.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html>