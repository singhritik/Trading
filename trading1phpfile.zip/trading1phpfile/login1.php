



<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <title>MY Trading</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8" />
    <meta name="keywords" content="Pervasive Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- Custom Theme files -->
    <link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
    <link href="css/style.css" type="text/css" rel="stylesheet" media="all">
    <!-- font-awesome icons -->
    <link href="css/fontawesome-all.min.css" rel="stylesheet">
	<!-- pop up box -->
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
    <!-- //Custom Theme files -->
    <!-- online-fonts -->
    <link href="http://fonts.googleapis.com/css?family=Ubuntu:300,300i,400,400i,500,500i,700,700i" rel="stylesheet">
    <!-- //online-fonts -->
</head>

<body>
    <!-- banner -->
    <div class="banner">
        <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-gradient-secondary pt-3">
                <h1>
                    <a class="navbar-brand text-white" href="index1.php">
                        <img src="images/logo.png" width=50%>
                    </a>
                </h1>
                <button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-lg-auto text-center">
                        <li class="nav-item active  mr-3 mt-lg-0 mt-3">
                            <a class="nav-link" href="index.html">Home
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item  mr-3 mt-lg-0 mt-3">
                            <a class="nav-link" href="about.php">About</a>
                        </li>
						<li class="nav-item  mr-3 mt-lg-0 mt-3">
                            <a class="nav-link" href="index.php">Register</a>
                        </li>
                        <li class="nav-item  mr-3 mt-lg-0 mt-3">
                            <a class="nav-link" href="#signin">Sign In</a>
                        </li>
                        <li class="nav-item mr-3 mt-lg-0 mt-3">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                    </ul>
                </div>  
			</nav>
        </header>
        <!-- //header -->
        <div class="container">
            <!-- banner-text -->
            <div class="banner-text">
                <div class="slider-info">
                    <h3>LET’S START TRADING</h3>
					<p class="mt-3">I am Ankit Namdev. On behalf of the global research services is writing this letter to offer our portfolio Management services to you. It will be a great pleasure to provide you the trading services from us. As per our discussio we have inform you about our profit management services.</p>
                    <a class="btn btn-primary mt-lg-5 mt-3 agile-link-bnr" href="about.php" role="button">View More</a>
                </div>
            </div>
        </div>
    </div>
	 <!-- //banner-text -->
	 <!-- counter -->
	<div class="services-bottom stats services py-lg-5">
		<div class="container py-5">
			<div class="row wthree-agile-counter">
				  
					<div class="col-lg-3 col-md-6 col-sm-6 w3_agile_stats_grid-top">
						<div class="w3_agile_stats_grid">
							<div class="agile_count_grid_left">
								<i class="far fa-clock"></i>
							</div>
							<div class="agile_count_grid_right">
								<p class="counter">1543</p> 
								<h4>Working Hours</h4>
							</div>
							<div class="clearfix"> </div>
							
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6 w3_agile_stats_grid-top">
						<div class="w3_agile_stats_grid">
							<div class="agile_count_grid_left">
								<i class="far fa-star"></i>
							</div>
							<div class="agile_count_grid_right">
								<p class="counter">434</p>
								<h4>Feedbacks</h4>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6 w3_agile_stats_grid-top">
						<div class="w3_agile_stats_grid">
							<div class="agile_count_grid_left">
								<i class="far fa-heart"></i>
							</div>
							<div class="agile_count_grid_right">
								<p class="counter">234</p>
								<h4>Happy Clients</h4>					
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
			</div>
		</div>
	</div>

    <form action="logincheck.php" method="post">
	     <!-- contact -->
        <div class="contact-wthree py-md-5 py-4" id="signin">
        <div class="container py-lg-5">
            <div class="text-center wthree-title pb-sm-5 pb-3">
                <h3 class="tittle-w3ls pb-4">Sign In</h3>
               
            </div>
                    <div class="project-top mx-auto mt-lg-0 mt-5">
                        <!-- register form grid -->
                        <div class="register-top1">
                            
                				<div class="form-group">
                                    <div class="row">
										<div class="col-md-12">
                                         <?php
                   							 if(isset($_REQUEST["err"]))
                        						echo "Invalid Username or Password";
                						?>  
                                           
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
										<div class="col-md-12">
                                           
                                            <input class="form-control" type="text" placeholder="Enter Referal Id" name="referid" required="">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                     
                                        <div class="col-md-12">
                                          
                                            <input class="form-control" type="password" placeholder="Enter password" name="password" required="">
                                        </div>
                                    </div>
                                </div>
								
                                <div class="row mt-lg-5 mt-3">
                                  
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-agile btn-block w-100">Sign In</button>
                                    </div>
                                </div>
                            
                        </div>
                        <!--  //register form grid ends here -->
                    </div>
               
            </div>
        </div>
        </form>
        <!-- //contact -->
	<!-- footer -->
	<footer class="footer-emp bg-dark py-5">
		<div class="container">
			<div class="row footer-top">
				<div class="col-lg-4 footer-grid pr-5">
					<h2 class="footer-title border-bottom text-uppercase mb-4 pb-3">About Us</h2>
					<div class="footer-text">
						
						<p>I am Ankit Namdev. On behalf of the global research Services is writing this letter to offer our portfolio Management services.</p>

					</div>
				</div>
				<div class="col-lg-4 footer-grid my-lg-0 my-4">
					<h3 class="footer-title border-bottom text-uppercase mb-4 pb-3">Quick Links</h3>
					<ul class="links list-unstyled">
						<li>
							<a href="index.php">Home</a>
						</li>
						<li class="my-2">
							<a href="about.php">About Us</a>
						</li>
						<li>
							<a href="#register">Register</a>
						</li>
						<li class="my-2">
							<a href="login1.php">Sign In</a>
						</li>
						<li class="mt-2">
							<a href="contact.php">Contact</a>
						</li>
					</ul>
					
					
				</div>
				<div class="col-lg-4 footer-grid">
					<h3 class="footer-title border-bottom text-uppercase mb-4 pb-3">Contact Us</h3>
					<div class="contact-info">
						<ul class="list-unstyled">
							<li>
								<div class="row">
									<div class="col-1">
										<i class="fas fa-map-marker"></i>
									</div>
									<div class="col-11">
										<p>The Global Research Online
											<span>Flat No 101,102 1st Floor, BCM heights, Opposite Mit City Hostel, Avantikapuri 1st lane, Ujjain</span></p>
									</div>
								</div>
							</li>
							<li class="my-2">
								<div class="row">
									<div class="col-1">
										<i class="fas fa-phone"></i>
									</div>
									<div class="col-11">
											<p>+91 9522735368</p>
									</div>
								</div>
							</li>
							<li>
								<div class="row">
									<div class="col-1">
										<i class="fas fa-envelope"></i>
									</div>
									<div class="col-11">
										<a href="mailto:info@theglobalresearchonline.com">info@theglobalresearchonline.com</a>
									</div>
								</div>
							</li>
						</ul>

					</div>
					<ul class="footer-social mt-md-4 mt-3">
						<li class="mx-2">
							<a href="#">
								<span class="fab fa-facebook-f"></span>
							</a>
						</li>
						<li class="mx-2">
							<a href="#">
								<span class="fab fa-twitter"></span>
							</a>
						</li>
						<li class="mx-2">
							<a href="#">
								<span class="fab fa-google-plus-g"></span>
							</a>
						</li>
						<li class="mx-2">
							<a href="#">
								<span class="fab fa-linkedin-in"></span>
							</a>
						</li>
						<li class="mx-2">
							<a href="#">
								<span class="fas fa-rss"></span>
							</a>
						</li>
						<li class="mx-2">
							<a href="#">
								<span class="fab fa-vk"></span>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
	<div class="copyright py-3">
		<p class="copy-right text-center ">&copy; 2018 Pervasive. All Rights Reserved | Design by Ritik singh</a>
		</p>
	</div>
	<!-- //footer -->


<!-- js -->
    <script src="js/jquery-2.2.3.min.js"></script>
<!-- //js -->
<!-- stats -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.countup.js"></script>
		<script>
			$('.counter').countUp();
		</script>
   <script src="js/move-top.js"></script>
    <script src="js/easing.js"></script>
    <script src="js/SmoothScroll.min.js"></script>
    <script src="js/bootstrap.js"></script>
</body>

</html>