<?php
	session_start();
    if(!isset($_SESSION["login"]))
        header("location:login.php");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection

$item= $_POST["item"];
$invoiceid = $_REQUEST["invoiceid"];
$qnty = $_REQUEST["qnty"];
$cname = $_REQUEST["cname"];
$customercity = $_REQUEST["customercity"];
$duedate = $_REQUEST["duedate"];
$issuedate = $_REQUEST["issuedate"];
$subject = $_REQUEST["subject"];



if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT price FROM items WHERE itemname = '".$item."'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $price=$row["price"];
    }
} else {
    echo "0 results";
}


mysqli_close($conn);
?> 


<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";


// Create connection
$conn = mysql_connect($servername, $username, $password, $dbname);
// Check connection

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
     mysql_select_db($dbname,$conn); 
    $sql= "INSERT into details (invoiceid, cname, item, qnty, customercity, duedate, issuedate) values ('$_POST[invoiceid]','$_POST[cname]','$_POST[item]','$_POST[qnty]','$_POST[customercity]','$_POST[duedate]','$_POST[issuedate]')";
        

    if(!mysql_query($sql,$conn)){
       die('Error:'.mysql_error());
    }
    mysql_close($conn);
?> 


<!DOCTYPE html>
<html>
<head>
    <title>Invoice Bill</title>
    <style>
        *{
            padding:auto;
            margin:auto;
        }
        .page{
            width:80%;
            border:2px solid black;
            margin-right:10%;
            margin-left:10%
            margin-top:2%;
        }
        .company{
            text-align:center;
            font-size: 30px;
            color: black;
            margin-top:3%;
        }   
        .invoice{
            padding:10px;   
        }
        .from{
            padding:10px;
            float:left;
        }
        .for{
            padding:10px;
            float:right;
        }
        .clear{
            clear:both;
        }
        .sub{
            padding:5%;
        }
        #bill th{
            border:1px solid black;
            padding-top:10px;
            padding-bottom:10px;
            padding-left:20px;
            padding-right:20px;
            background:black;
            color:white;
        }
        #bill td{
            border:1px solid black;
            padding-top:10px;
            padding-bottom:10px;
            padding-left:20px;
            padding-right:20px;
            color:black;
        }
        .btn button{
            background:blue;
            color:white;
            padding:10px;
            border-radius:10px;
        }
        
        
    </style>
</head>
<body>
    <div class="page">
    <div class="company">RS Electronics</div>
    <div class="btn"><button onclick="myFunction()">Print Invoice</button></div>
    <div style="float:right; padding-right: 20px;">
        <a href="logout.php">Logout</a> 
    </div>
    <div style="clear: both;"></div>
    <div class="invoice">
        <table cellspacing="15px">
            <tr>
                <td>Invoice Id</td>
                <td><?php echo $invoiceid ?></td>
            </tr>
            <tr>
                <td>Issue Date</td>
                <td><?php echo $issuedate ?></td>
            </tr>
            <tr>
                <td>Due Date</td>
                <td><?php echo $duedate ?></td>
            </tr>
        </table>
    </div>
    <div class="from">
        <p>From</p>
        <table cellspacing="15px">
            <tr>
                <td>Name</td>
                <td>Ritik singh</td>
            </tr>
            <tr>
                <td>Address</td>
                <td>Indore, M.P.</td>
            </tr>
            <tr>
                <td>Email</td>
                <td>singhritik860@gmail.com</td>
            </tr>
            <tr>
                <td>Contact No.</td>
                <td>8269952793</td>
            </tr>
        </table>
    </div>
    <div class="for">
        <p>For</p>
        <table cellspacing="15px">
            <tr>
                <td>Customer Name</td>
                <td><?php echo $cname ?></td>
            </tr>
            <tr>
                <td>Address</td>
                <td><?php echo $customercity ?></td>
            </tr>
        </table>
    </div>
    <div class="clear"></div>
    <div>
        <label class="sub">Subject:</label>
        <label><?php echo $subject ?></label>
        </div><br>
        <hr>
    <center>
    <div>
        <table id="bill">
            <tr>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Subprice</th>
                <th>VAT Tax(4%)</th>
                <th>total</th>
            </tr>
            <tr>
                <td><?php echo $item ?></td>
                <td><?php echo $qnty ?></td>
                <td><?php echo $price ?></td>
                <td>
                <?php $price1= $qnty*$price;
                    $price2= (4/100)*$price1; 
                    echo $price1;
                ?>
                </td>
                <td>
                <?php $price1= $qnty*$price;
                    $price2= (4/100)*$price1; 
                    echo $price2;
                ?>
                </td>
                <td><?php 
                    $price1= $qnty*$price;
                    $price2= (4/100)*$price1;
                    $totalprice= $price1+$price2;
                    echo $totalprice;
                ?></td>
            </tr>
        </table>
    </div></center>
    <br><br><br><br><br>
    <hr>
    <labela>Note : Keep payment process complete under duedate.</label>
    <div><div><br><br>
	<center><label>Design by Ritik singh<label></center>

    <script>
        function myFunction(){
        window.print();
    }
    </script>
</body>
</html>



