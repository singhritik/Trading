
-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `fname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `adhaarno` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `panno` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `referalid` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobileno` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`fname`, `lname`, `email`, `adhaarno`, `panno`, `referalid`, `password`, `mobileno`) VALUES
('', '', '', '', '', NULL, NULL, ''),
('Akhtari', 'Begum', 'akhtari.shaikh@outlook.com', '604686533478', 'AZCPS3907P', 'Akht/6046', 'Ak@B98', '9920939902'),
('Govind', 'Gurjar', 'govindgurjar020@gmail.com', '913085888137', 'BQKPG9076R', 'GO30RJ@P', 'K97R#851', '9405276171'),
('Pawan', 'Kumar', 'kashyapk2015@gmail.com', '496856126570', 'CEMPK1419R', 'Pawan@18', 'JITE@416', '9817771660'),
('Kishor', 'Ahire ', 'Kishorahire125@gmail.com', '242407181880', 'BLQPA2629R', 'KISHOR8696', 'JITE@807', '8149502993'),
('Musthafa ', 'Mohammed ', 'Musthafauna1997@gmail.com', '254453311029', 'DDSPM0635K', 'Musthafa0703', 'JI@SM037', '9008198554'),
('Omprakash', 'Randva', 'Omprakashrandwa@gmail.com', '816030141443', 'BXJPR3995n', 'OMJIKL@76', 'JITE@106', '9926039285'),
('Pramod ', 'Thakur ', 'PramodsinghthakurO@gmail.com', '974540833888', 'BGIPT2524D ', 'Pramod2681', 'JITE@BH9', '9098066622'),
('Satish ', 'Kumar', 'satishkumar29031982@gmail.com', '737826016297', 'BIIPM0418H', 'Sateeh@8', 'SA76@F59', '6265664848'),
('Afreen', 'Shaikh', 'shaikhtoto@gmail.com', '416134637994', 'AAHPQ6637Q', 'SA76@F59', 'Afreen@8', '8830633030'),
('Somnath', 'Paul', 'somnath.paul2010@gmail.com', '335166059433', 'BOVPP9869N', 'MSB@4309', 'V98PM601', '9804521732'),
('Sudheesh', 'M. D', 'sudheesh55 md@gmail.com', '345648664447', 'CFCPS7706E', 'Sudheesh86', 'NR770@18', '9947123354'),
('sudheesh', 'Nair ', 'sudheesh55md@gmail.com', '345648664447', 'CFCPS7706E', 'Sudheesh86', 'NR770@18', '9947123354'),
('Tejas', 'Khatalik', 'tejaskhatalik@gmail.com', '9900321789', 'Avjpk8936p', NULL, NULL, '9371967118');
