
-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `mobileno` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `adminid` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(40) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `email`, `mobileno`, `adminid`, `password`, `address`) VALUES
('Abhishek maratha', 'info@globalresearchonline.com', '9522735368', 'abhi123', 'Navya4441@', 'Avantikapuri, Ujjain'),
('Abhishek maratha', 'info@globalresearchonline.com', '9522735368', 'abhi123', 'Navya4441@', 'Avantikapuri, Ujjain');
